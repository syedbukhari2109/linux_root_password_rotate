# 🔐 Automated Password Rotation with Ansible & Hashi Corp Vault

This Ansible project automates **local user password rotation across multiple hosts** using **HashiCorp Vault** for secure password generation and storage. It checks when the password was last changed, determines whether rotation is needed, generates new credentials via Vault, and optionally emails a detailed rotation report.

---

## 📦 Features

- ✅ Checks if a local user exists
- 🗓️ Compares last password change date against a defined threshold
- 🔐 Authenticates to Vault via LDAP
- 🔁 Rotates password using Vault's secure password generator
- 🗃️ Stores new password in Vault KV store
- 💾 Updates the user's password on the host
- 📊 Generates an Excel report with rotation status
- 📧 Sends email summary with attached report

---

## 🧰 Requirements

- Ansible 2.10+
- Python 3 with `pip`
- Vault server with:
  - LDAP auth enabled
  - KV secrets engine
  - Password generation endpoint (`password-gen` plugin)
- Python `xlsxwriter` module on the control node (auto-installed)
- `community.general` Ansible collection for sending email

---

## 📧 Email Report

The report includes:
 - ✅ A list of hosts where passwords were rotated
 - ✅ A list of hosts where password rotation was skipped
 - ✅ An Excel attachment with full rotation results

---

## 🛠️ Setup

1. **Configure required variables:**

   ```bash
   git clone https://github.com/your-org/password-rotation-ansible.git
   cd password-rotation-ansible

2. **Clone this repository:**
   ```bash
   username: "localuser"
   password_min_age_days: 30
   vault_addr: "https://vault.example.com"
   vault_namespace: "admin"
   vault_ldap_user: "ldap_user"
   VAULT_LDAP_PASS: "your_password"
   ldap_mount: "ldap"
   vault_kv_path: "kv/users"
   password_length: 20
   password_symbols: true
   password_digits: true
   allow_uppercase: true
   email_host: "smtp.example.com"
   email_port: 587
   email_from: "ansible@yourdomain.com"
   email_recipients:
   - "admin@yourdomain.com"  

3. **Templates Required:**
   
   `write_password_report.py.j2`: Python script template to generate Excel file
   
   `email_body.html.j2`: HTML email body template
   
4. **Structure:**
   ```
    .
    ├── defaults/
    |   └── main.yml
    ├── tasks/
    |   ├── main.yml
    |   ├── check_user.yml
    |   ├── vault_auth.yml
    |   ├── update_password.yml
    |   ├── multi_hosts.yml
    |   └── report.yml
    ├── templates/
    │   ├── write_password_report.py.j2
    │   └── email_body.html.j2
    └── README.md

